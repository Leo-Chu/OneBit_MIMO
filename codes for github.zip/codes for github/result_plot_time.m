function result_plot_time(tt, precoder)

        qq = 1:length(tt);
        semilogy(qq,tt(:,1),'-d',qq,tt(:,2),'-*',qq,tt(:,3) ,'-^',...
                qq,tt(:,4) ,'-+',qq,tt(:,5) ,'-k', 'LineWidth',1);
        grid on
        title(precoder)
        legend('N=16', 'N=32', 'N=64', 'N=128', 'N=256') 

        xlabel('number of executions')
        ylabel('Computaional time')

end