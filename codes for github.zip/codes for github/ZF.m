
function [x, beta, P] = ZF(s, H)

    % precoding factor
    HHV = inv(H*H');	
    %beta = sqrt(trace((H*H')^-1)); 
    beta = sqrt(trace(HHV)); 	
    
    % precoding matrix
    P = 1/beta * H'*HHV;

    % precoded vector
    x = P*s;

end
